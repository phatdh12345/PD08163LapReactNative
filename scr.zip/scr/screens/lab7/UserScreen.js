import { Text, View } from "react-native";
const User = () =>{
    return(
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <Text style={{color: '#006600', fontSize:40}}>UserScreen</Text>
        </View>
    );
};
export default User;