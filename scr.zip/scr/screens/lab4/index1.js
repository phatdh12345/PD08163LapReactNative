import React from 'react';
import { View, Text } from 'react-native';
import ListCourse from '../../../components/list';


const Lab4 = () => {
  return (
    <View>
      <ListCourse />
    </View>
  );
};

export default React.memo(Lab4);