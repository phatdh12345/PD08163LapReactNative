import React from 'react';
import {Text, Pressable, Image, View} from 'react-native';

import {styles} from './styles';
const AuthHeader = ({title, onBackPress}) => {
  return (
    <View style={styles.container}>
      <Pressable onPress={onBackPress}>
        <Image
          style={styles.iconBack}
          source={require('../../assets/icon.png')}/>
      </Pressable>
      <Text style={styles.title}>{title}</Text>
    </View>
  );
};

export default AuthHeader;